from flask import Blueprint, jsonify
from api.services.user_service import UserService
from api.services.product_service import ProductService
from api.services.product_service_by_id import ProductServiceById

def register_routes(app, mysql):
    api_bp = Blueprint('api', __name__)

    user_service = UserService(mysql)
    product_service = ProductService(mysql)
    product_service_by_id = ProductServiceById(mysql)

    @api_bp.route('/users', methods=['GET'])
    def get_users():
        return jsonify(user_service.get_all_users())

    @api_bp.route('/products', methods=['GET'])
    def get_products():
        return jsonify(product_service.get_all_products())

    @api_bp.route('/products_by_id/<int:product_id>', methods=['GET'])
    def get_products_by_id(product_id):
        return jsonify(product_service_by_id.get_product_by_id(product_id))

    # REGISTRO FINAL DEL BLUEPRINT
    app.register_blueprint(api_bp)
