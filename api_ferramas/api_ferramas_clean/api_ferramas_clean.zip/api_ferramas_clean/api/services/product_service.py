from api.models.product import Product

class ProductService:
    def __init__(self, mysql):
        self.mysql = mysql

    def get_all_products(self):
        cursor = self.mysql.connection.cursor()
        cursor.execute("SELECT id, nombre, descripcion, imagen, precio, stock FROM product")
        results = cursor.fetchall()
        cursor.close()

        products = [
            Product(
                id=row[0],
                nombre=row[1],
                descripcion=row[2],
                imagen=row[3],
                precio=row[4],
                stock=row[5]
            ).to_dict()
            for row in results
        ]

        return products
